How to use the makefile

Move to src folder

Type "make"

Commands: 
	  make teams00
	  make teams01
	  make teams02
	  make teams04
	  make teams08
	  make teams16
	  make teams32 

	  make clean

If this does not work move to src folder
Type: 	javac application/*.java
	java application.Main teams16.txt


Schmidts-Air:cs400Bracket gubba$ cd src

Schmidts-Air:src user$ ls
AlertScreenShot.png	teams00.txt		teams04.txt
Makefile		teams02.txt		teams16.txt
ReadMe.txt		teams01.txt		teams08.txt
ScreenShot.png		teams32.txt
application	
				
Schmidts-Air:src user$ make
javac application/*.java

Schmidts-Air:src user$ make teams16
java application.Main teams16.txt > teams16.log

Schmidts-Air:src user$ make clean
\rm application/*.class

