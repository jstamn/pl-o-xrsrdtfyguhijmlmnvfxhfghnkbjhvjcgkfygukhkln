package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.TextAlignment;

////////////////////////////////////////////////////////////////////////////
//Semester:			CS400 Spring 2018
//PROJECT:			P4 Bracket GUI
//FILES:				Main.java
//					Round.java
//					Challenger.java
//
//USER:				tschmidt6@wisc.edu | Teryl Schmidt
//					alsilverman3@wisc.edu | Avi Silverman
//					jsoukup2@wisc.edu | Joe Soukup
//					smulvey2@wisc.edu | Steven Mulvey
//					jstamn@wisc.edu | Joshua Stamn
//
//
//Instructor:		Deb Deppeler (deppeler@cs.wisc.edu)
//Bugs:				no known bugs
//
//Due:				2018 May 3, 2018 Main.java
////////////////////////////80 columns wide //////////////////////////////////

public class Main extends Application {

	static ObservableList<String> teamNames = FXCollections.observableArrayList(); //Holds team names
	private int count = teamNames.size(); //Number of teams in list
	Round TopTwoRound = new Round(teamNames); //Holds Top Two Challengers
	Round FinalFourRound = new Round(teamNames); //Holds Top Four Challengers
	Round EliteEightRound = new Round(teamNames); //Holds Top Eight Challengers
	Round SweetSixteenRound = new Round(teamNames); //Holds Top Sixteen Challengers
	Round TopThirtyTwoRound = new Round(teamNames); //Holds Top Thirty-two Challengers


	public static void main(String[] args) {

		String fileName = args[0] ; // Testing just set to filename to "teams04.txt" , "teams16.txt" . . . 
		File inputFile = null;
		Scanner sc = null;

		/**
		 * Opens file specified in args[0]
		 * File must have 0,1,2,4,8,16,32 lines of text
		 */
		try {
			inputFile = new File(fileName);
			sc = new Scanner(inputFile);
			while(sc.hasNextLine()) {
				//Adding lines of text to teamNames List
				String name = sc.nextLine();
				teamNames.add(name);
			}
			sc.close();
		} catch (Exception ex) {
			System.err.println("Can't Open File " + fileName);
			System.exit(-1);
		}
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) {

		try {	
			
			//Creates a window to put the bracket into
			primaryStage.setTitle("Bracket GUI");
			GridPane gPane = new GridPane();
			Scene scene = new Scene(gPane, 1250, 700, Color.WHEAT);
			
			////// SPECIAL CASE 0: Nothing in text file //////

			Challenger Winner = new Challenger();
			if (count == 0) {
				Winner.setName("There are no teams!");
				gPane.add(Winner.getLabel(), 0, 0);
			}

			////// SPECIAL CASE 1: Only one name in text file //////

			Challenger Second = new Challenger();
			Challenger Third = new Challenger();

			Label SecondPlaceInfo = new Label();
			Label ThirdPlaceInfo = new Label();
			SecondPlaceInfo.setText("2nd: ");
			ThirdPlaceInfo.setText("3rd: ");

			Winner.getLabel().setTextAlignment(TextAlignment.CENTER);
			if (count == 1) {
				Winner.setName(teamNames.get(0)); //If one team, it is the winner
			} else if (count >= 1) {
				Winner.setName("TBD"); //Otherwise winner has not been determined yet
			}

			if (count >= 1) {
				gPane.add(Winner.getLabel(), 10, 15); //Can't have a winner if there are no teams in the text file
			}
			//Don't add 2nd and 3rd place unless there is more than 1 team
			if (count > 1) {
				gPane.add(Second.getLabel(), 10, 17);
				gPane.add(SecondPlaceInfo, 9, 17);
				gPane.add(Third.getLabel(), 10, 18);
				gPane.add(ThirdPlaceInfo, 9, 18);
			}

			//////////////////// TOP TWO ////////////////////

			if (count > 1) { //This will only run if there are more than 1 name in text file

				if (count == 2) {
					TopTwoRound.fillFirstRound(teamNames); //If 2 names then fill that round with actual names
				} else {
					TopTwoRound.fillRound(teamNames); //Otherwise fill it with "TBD"
				}

				Button TopTwoButton = new Button();

				TopTwoButton.setText("Submit");
				TopTwoButton.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle(ActionEvent event) {
						if (TopTwoRound.BothChallengersReady(TopTwoRound.challengers[0], TopTwoRound.challengers[1])) {
						//Get winner
						Winner.setName(TopTwoRound.Play(TopTwoRound.challengers[0], TopTwoRound.challengers[1]).getName());
						//Get second place
						if (Winner.getName().equals(TopTwoRound.challengers[0].getName())) {
							Second.setName((TopTwoRound.challengers[1].getName()));
						} else {
							Second.setName((TopTwoRound.challengers[0].getName()));
						}
						//Get third place
						if (count > 2) {
							Third.setName(FinalFourRound.getThird(Winner, Second));
						}
							TopTwoButton.setDisable(true);
						}
					}
				});

				//If two names in text file there is no third place
				Second.setName("TBD");
				if (count > 2) {
					Third.setName("TBD");
				} else {
					Third.setName("None");
				}

				// Add labels, text fields and button
				gPane.add(TopTwoRound.challengers[0].getLabel(), 8, 15);
				gPane.add(TopTwoRound.challengers[1].getLabel(), 12, 15);
				gPane.add(TopTwoRound.challengers[0].getTextField(), 9, 15);
				gPane.add(TopTwoRound.challengers[1].getTextField(), 11, 15);
				gPane.add(TopTwoButton, 10, 16);
			}

			//////////////////// FINAL FOUR ////////////////////

			if (count > 2) { //Will only run if there are more than 2 names in text file

				if (count == 4) {
					FinalFourRound.fillFirstRound(teamNames); // If 4 teams fill with actual names
				} else {
					FinalFourRound.fillRound(teamNames); // Otherwise fill with "TBD"
				}

				//Using lambda here, shorter version of above code on line 140
				//These buttons only determine the winner of two Challengers
				// Ex) Button[0] determines the winner of two Final Four challengers and the winner moves into the Top Two
				FinalFourRound.submitButtons[0].setOnAction(actionEvent -> { if (FinalFourRound.BothChallengersReady(FinalFourRound.challengers[0], FinalFourRound.challengers[1])) {
				TopTwoRound.challengers[0].setName(FinalFourRound.Play(FinalFourRound.challengers[0], FinalFourRound.challengers[1]).getName());}
				if (TopTwoRound.challengers[0].getName() != "TBD") { FinalFourRound.submitButtons[0].setDisable(true);}});
				
				FinalFourRound.submitButtons[1].setOnAction(actionEvent -> { if (FinalFourRound.BothChallengersReady(FinalFourRound.challengers[2], FinalFourRound.challengers[3])) {
				TopTwoRound.challengers[1].setName(FinalFourRound.Play(FinalFourRound.challengers[2], FinalFourRound.challengers[3]).getName());}
				if (TopTwoRound.challengers[1].getName() != "TBD") { FinalFourRound.submitButtons[1].setDisable(true);}});
		
				

				// Put Labels and text fields in grid 
				for (int i = 0, j = 2, k = 14; i < 2; i++, j++, k+=2) {
					gPane.add(FinalFourRound.challengers[i].getLabel(), 6, k);
					gPane.add(FinalFourRound.challengers[i].getTextField(), 7, k);
					gPane.add(FinalFourRound.challengers[j].getLabel(), 14, k); 
					gPane.add(FinalFourRound.challengers[j].getTextField(), 13, k);
				}

				// Put Buttons into grid
				gPane.add(FinalFourRound.submitButtons[0], 6 ,15);
				gPane.add(FinalFourRound.submitButtons[1], 14 ,15);
			}

			//////////////////// ELITE EIGHT ////////////////////

			if (count > 4) { //Will only run if there are more than 4 names in text file

				if (count == 8) {
					EliteEightRound.fillFirstRound(teamNames); // If 8 teams fill with actual names
				} else {
					EliteEightRound.fillRound(teamNames); // Otherwise fill with "TBD"
				}

				// Add functionality to buttons
				// These buttons determine the winner of two Challengers
				EliteEightRound.submitButtons[0].setOnAction(actionEvent -> { if (EliteEightRound.BothChallengersReady(EliteEightRound.challengers[0], EliteEightRound.challengers[1])) {
				FinalFourRound.challengers[0].setName(EliteEightRound.Play(EliteEightRound.challengers[0], EliteEightRound.challengers[1]).getName());}
				if (FinalFourRound.challengers[0].getName() != "TBD") { EliteEightRound.submitButtons[0].setDisable(true);}});
				
				EliteEightRound.submitButtons[1].setOnAction(actionEvent -> { if (EliteEightRound.BothChallengersReady(EliteEightRound.challengers[2], EliteEightRound.challengers[3])) {
				FinalFourRound.challengers[1].setName(EliteEightRound.Play(EliteEightRound.challengers[2], EliteEightRound.challengers[3]).getName());}
				if (FinalFourRound.challengers[1].getName() != "TBD") { EliteEightRound.submitButtons[1].setDisable(true);}});

				//Right side Buttons
				EliteEightRound.submitButtons[2].setOnAction(actionEvent -> { if (EliteEightRound.BothChallengersReady(EliteEightRound.challengers[4], EliteEightRound.challengers[5])) {
				FinalFourRound.challengers[2].setName(EliteEightRound.Play(EliteEightRound.challengers[4], EliteEightRound.challengers[5]).getName());}
				if (FinalFourRound.challengers[2].getName() != "TBD") { EliteEightRound.submitButtons[2].setDisable(true);}});
				
				EliteEightRound.submitButtons[3].setOnAction(actionEvent -> { if (EliteEightRound.BothChallengersReady(EliteEightRound.challengers[6], EliteEightRound.challengers[7])) {
				FinalFourRound.challengers[3].setName(EliteEightRound.Play(EliteEightRound.challengers[6], EliteEightRound.challengers[7]).getName());}
				if (FinalFourRound.challengers[3].getName() != "TBD") { EliteEightRound.submitButtons[3].setDisable(true);}});

				// Put Labels and text fields in grid 
				for (int i = 0, j = 4, k = 12; i < 4; i++, j++, k+=2) {
					gPane.add(EliteEightRound.challengers[i].getLabel(), 4, k);
					gPane.add(EliteEightRound.challengers[i].getTextField(), 5, k);
					gPane.add(EliteEightRound.challengers[j].getLabel(), 16, k);
					gPane.add(EliteEightRound.challengers[j].getTextField(), 15, k);
				}

				// Put Buttons into grid
				for (int i = 0, j = 2, k = 13; i < 2; i++, j++, k+=4) {
					gPane.add(EliteEightRound.submitButtons[i], 4, k);
					gPane.add(EliteEightRound.submitButtons[j], 16, k);
				}
			}

			//////////////////// SWEET SIXTEEN ////////////////////

			if (count > 8) { //Will only run if there are more than 8 names in text file

				if (count == 16) {
					SweetSixteenRound.fillFirstRound(teamNames); // If 16 teams fill with actual names
				} else {
					SweetSixteenRound.fillRound(teamNames); // Otherwise fill with "TBD"
				}

				// Add functionality to buttons
				// These buttons determine the winner of two Challengers
				
				//Left side buttons
				SweetSixteenRound.submitButtons[0].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[0], SweetSixteenRound.challengers[1])) {
				EliteEightRound.challengers[0].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[0], SweetSixteenRound.challengers[1]).getName());}
				if (EliteEightRound.challengers[0].getName() != "TBD") { SweetSixteenRound.submitButtons[0].setDisable(true);}});
				
				SweetSixteenRound.submitButtons[1].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[2], SweetSixteenRound.challengers[3])) {
				EliteEightRound.challengers[1].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[2], SweetSixteenRound.challengers[3]).getName());}
				if (EliteEightRound.challengers[1].getName() != "TBD") { SweetSixteenRound.submitButtons[1].setDisable(true);}});
				
				SweetSixteenRound.submitButtons[2].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[4], SweetSixteenRound.challengers[5])) {
				EliteEightRound.challengers[2].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[4], SweetSixteenRound.challengers[5]).getName());}
				if (EliteEightRound.challengers[2].getName() != "TBD") { SweetSixteenRound.submitButtons[2].setDisable(true);}});
				
				SweetSixteenRound.submitButtons[3].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[6], SweetSixteenRound.challengers[7])) {
				EliteEightRound.challengers[3].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[6], SweetSixteenRound.challengers[7]).getName());}
				if (EliteEightRound.challengers[3].getName() != "TBD") { SweetSixteenRound.submitButtons[3].setDisable(true);}});

				//Right side buttons
				SweetSixteenRound.submitButtons[4].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[8], SweetSixteenRound.challengers[9])) {
				EliteEightRound.challengers[4].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[8], SweetSixteenRound.challengers[9]).getName());}
				if (EliteEightRound.challengers[4].getName() != "TBD") { SweetSixteenRound.submitButtons[4].setDisable(true);}});
				
				SweetSixteenRound.submitButtons[5].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[10], SweetSixteenRound.challengers[11])) {
				EliteEightRound.challengers[5].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[10], SweetSixteenRound.challengers[11]).getName());}
				if (EliteEightRound.challengers[5].getName() != "TBD") { SweetSixteenRound.submitButtons[5].setDisable(true);}});
			
				SweetSixteenRound.submitButtons[6].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[12], SweetSixteenRound.challengers[13])) {
				EliteEightRound.challengers[6].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[12], SweetSixteenRound.challengers[13]).getName());}
				if (EliteEightRound.challengers[6].getName() != "TBD") { SweetSixteenRound.submitButtons[0].setDisable(true);}});
				
				SweetSixteenRound.submitButtons[7].setOnAction(actionEvent -> { if (SweetSixteenRound.BothChallengersReady(SweetSixteenRound.challengers[14], SweetSixteenRound.challengers[15])) {
				EliteEightRound.challengers[7].setName(SweetSixteenRound.Play(SweetSixteenRound.challengers[14], SweetSixteenRound.challengers[15]).getName());}
				if (EliteEightRound.challengers[7].getName() != "TBD") { SweetSixteenRound.submitButtons[7].setDisable(true);}});

				// Put Labels and text fields in grid 
				for (int i = 0, j = 8, k = 8; i < 8; i++, j++, k+=2) {
					gPane.add(SweetSixteenRound.challengers[i].getLabel(), 2, k);
					gPane.add(SweetSixteenRound.challengers[i].getTextField(), 3, k);
					gPane.add(SweetSixteenRound.challengers[j].getLabel(), 18, k);
					gPane.add(SweetSixteenRound.challengers[j].getTextField(), 17, k);
				}

				// Put Buttons into grid
				for (int i = 0, j = 4, k = 9; i < 4; i++, j++, k+=4) {
					gPane.add(SweetSixteenRound.submitButtons[i], 2 , k);
					gPane.add(SweetSixteenRound.submitButtons[j], 18 , k);
				}
			}

			//////////////////// TOP THIRTY-TWO ////////////////////

			if (count > 16) { //Will only run if there are more than 16 names in text file

				if (count == 32) {
					TopThirtyTwoRound.fillFirstRound(teamNames); // If 16 teams fill with actual names
				} else {
					// Doesn't go over 32 names so this won't happen
					TopThirtyTwoRound.fillRound(teamNames); // Otherwise fill with "TBD"
				}

				// Simpler buttons here with different functionality, but this section was not required for project
				/* 
				 * Anything invalid is considered 0 (negatives, alphanumeric, null)
				 * Can press any amount of times / doesn't matter if both scores have been entered
				 */
				TopThirtyTwoRound.submitButtons[0].setOnAction(actionEvent -> SweetSixteenRound.challengers[0].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[0], TopThirtyTwoRound.challengers[1]).getName()));
				TopThirtyTwoRound.submitButtons[1].setOnAction(actionEvent -> SweetSixteenRound.challengers[1].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[2], TopThirtyTwoRound.challengers[3]).getName()));
				TopThirtyTwoRound.submitButtons[2].setOnAction(actionEvent -> SweetSixteenRound.challengers[2].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[4], TopThirtyTwoRound.challengers[5]).getName()));
				TopThirtyTwoRound.submitButtons[3].setOnAction(actionEvent -> SweetSixteenRound.challengers[3].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[6], TopThirtyTwoRound.challengers[7]).getName()));
				TopThirtyTwoRound.submitButtons[4].setOnAction(actionEvent -> SweetSixteenRound.challengers[4].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[8], TopThirtyTwoRound.challengers[9]).getName()));
				TopThirtyTwoRound.submitButtons[5].setOnAction(actionEvent -> SweetSixteenRound.challengers[5].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[10], TopThirtyTwoRound.challengers[11]).getName()));
				TopThirtyTwoRound.submitButtons[6].setOnAction(actionEvent -> SweetSixteenRound.challengers[6].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[12], TopThirtyTwoRound.challengers[13]).getName()));
				TopThirtyTwoRound.submitButtons[7].setOnAction(actionEvent -> SweetSixteenRound.challengers[7].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[14], TopThirtyTwoRound.challengers[15]).getName()));

				TopThirtyTwoRound.submitButtons[8].setOnAction(actionEvent -> SweetSixteenRound.challengers[8].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[16], TopThirtyTwoRound.challengers[17]).getName()));
				TopThirtyTwoRound.submitButtons[9].setOnAction(actionEvent -> SweetSixteenRound.challengers[9].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[18], TopThirtyTwoRound.challengers[19]).getName()));
				TopThirtyTwoRound.submitButtons[10].setOnAction(actionEvent -> SweetSixteenRound.challengers[10].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[20], TopThirtyTwoRound.challengers[21]).getName()));
				TopThirtyTwoRound.submitButtons[11].setOnAction(actionEvent -> SweetSixteenRound.challengers[11].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[22], TopThirtyTwoRound.challengers[23]).getName()));
				TopThirtyTwoRound.submitButtons[12].setOnAction(actionEvent -> SweetSixteenRound.challengers[12].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[24], TopThirtyTwoRound.challengers[25]).getName()));
				TopThirtyTwoRound.submitButtons[13].setOnAction(actionEvent -> SweetSixteenRound.challengers[13].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[26], TopThirtyTwoRound.challengers[27]).getName()));
				TopThirtyTwoRound.submitButtons[14].setOnAction(actionEvent -> SweetSixteenRound.challengers[14].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[28], TopThirtyTwoRound.challengers[29]).getName()));
				TopThirtyTwoRound.submitButtons[15].setOnAction(actionEvent -> SweetSixteenRound.challengers[15].setName(TopThirtyTwoRound.Play(TopThirtyTwoRound.challengers[30], TopThirtyTwoRound.challengers[31]).getName()));

				// Put Labels and text fields in grid 
				for (int i = 0, j = 16, k = 0; i < 16; i++, j++, k+=2) {
					gPane.add(TopThirtyTwoRound.challengers[i].getLabel(), 0, k);
					gPane.add(TopThirtyTwoRound.challengers[i].getTextField(), 1, k);
					gPane.add(TopThirtyTwoRound.challengers[j].getLabel(), 20, k);
					gPane.add(TopThirtyTwoRound.challengers[j].getTextField(), 19, k);
				}

				// Put Buttons into grid
				for (int i = 0, j = 8, k = 1; i < 8; i++, j++, k+=4) {
					gPane.add(TopThirtyTwoRound.submitButtons[i], 0 , k);
					gPane.add(TopThirtyTwoRound.submitButtons[j], 20 , k);
				}

			}

			gPane.setGridLinesVisible(false); // Testing layout can see grid
			primaryStage.setScene(scene);
			primaryStage.show();	
			
			/**
			 * Show Alert Box to user
			 */
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("Rules");
			alert.setHeaderText("Rules for the games");
			alert.setContentText(" 1) Tie games are chosen randomly"
							 + "\n 2) Scores must contain only numbers or they are invalid"
							 + "\n 3) No score is invalid"
							 + "\n 4) Negative scores are invalid"
							 + "\n\n Click OK to continue to the bracket");
			alert.showAndWait();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
